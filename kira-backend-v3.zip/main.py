import sys
import uuid
import json
import os

# --------------- env var validation (runs before ANY other import) ---------------
# load_dotenv first so local .env works; in Catalyst the OS env is already populated.
from dotenv import load_dotenv
load_dotenv()

_REQUIRED_ENV = {
    "SUPABASE_URL":         "Supabase project URL (Settings → API → Project URL)",
    "SUPABASE_SERVICE_KEY": "Supabase service_role key (Settings → API → service_role)",
    "CEREBRAS_API_KEY":     "Cerebras cloud API key",
}
_missing = [k for k in _REQUIRED_ENV if not os.environ.get(k)]
if _missing:
    for k in _missing:
        print(f"[KIRA STARTUP ERROR] Missing env var: {k}  — {_REQUIRED_ENV[k]}", flush=True)
    print(f"[KIRA STARTUP ERROR] {len(_missing)} required env var(s) not set. Cannot start.", flush=True)
    sys.exit(1)

print("[KIRA STARTUP] All required env vars present — starting imports", flush=True)

# --------------- standard imports ---------------
from fastapi import FastAPI, Header, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import jwt as pyjwt
from jwt import PyJWKClient

from agents.router import classify_intent
from agents.responder import generate_response, AGENT_SETS
from agents.translator import detect_language
from memory.supabase_memory import (
    get_or_create_session,
    update_session,
    save_message,
    get_history,
    get_recent_context_string,
    get_audit_entries,
)
from db.entities import (
    get_entity_data,
    get_hotspots,
    get_recent_arrests,
    get_suspect,
    get_suspect_cases,
    get_suspect_evidence,
    get_user_profile,
)
from schemas.models import ChatRequest

SUPABASE_URL = os.environ["SUPABASE_URL"]
# PyJWKClient fetches Supabase's public JWKS, caches keys, and auto-selects
# the right key per token `kid`. Supports ES256 (asymmetric) out of the box.
_jwks_client = PyJWKClient(f"{SUPABASE_URL}/auth/v1/.well-known/jwks.json", cache_keys=True)

# --------------- map navigation helpers ---------------
_LOCATION_MAP: dict[str, dict] = {
    "whitefield":      {"lat": 12.9698, "lng": 77.7500, "zoom": 15, "label": "Whitefield"},
    "koramangala":     {"lat": 12.9352, "lng": 77.6245, "zoom": 15, "label": "Koramangala"},
    "electronic city": {"lat": 12.8452, "lng": 77.6602, "zoom": 14, "label": "Electronic City"},
    "shivajinagar":    {"lat": 12.9857, "lng": 77.6057, "zoom": 15, "label": "Shivajinagar"},
    "mg road":         {"lat": 12.9716, "lng": 77.5946, "zoom": 16, "label": "MG Road"},
    "indiranagar":     {"lat": 12.9719, "lng": 77.6412, "zoom": 15, "label": "Indiranagar"},
    "yeshwanthpur":    {"lat": 13.0284, "lng": 77.5541, "zoom": 14, "label": "Yeshwanthpur"},
    "bangalore":       {"lat": 12.9716, "lng": 77.5946, "zoom": 11, "label": "Bangalore"},
    "bengaluru":       {"lat": 12.9716, "lng": 77.5946, "zoom": 11, "label": "Bengaluru"},
}
_NAV_KEYWORDS = {"zoom", "show", "focus", "center", "map", "hotspot", "go to", "take me", "navigate", "where is", "locate", "fly to"}


def extract_map_action(query: str) -> dict | None:
    """Return map coordinates if the query is a location/navigation request."""
    q = query.lower()
    if not any(kw in q for kw in _NAV_KEYWORDS):
        return None
    for loc, coords in _LOCATION_MAP.items():
        if loc in q:
            return coords
    return None


# --------------- auth dependency ---------------

async def get_current_user(authorization: str = Header(None)) -> dict:
    """Validate the Supabase JWT and return the authenticated officer's profile."""
    if not authorization or not authorization.startswith("Bearer "):
        print("[KIRA backend] get_current_user: missing or malformed Authorization header")
        raise HTTPException(status_code=401, detail="Missing authentication token")

    token = authorization.split(" ", 1)[1]
    print(f"[KIRA backend] get_current_user: decoding token (prefix: {token[:20]}…)")

    try:
        signing_key = _jwks_client.get_signing_key_from_jwt(token)
        payload = pyjwt.decode(
            token,
            signing_key.key,
            algorithms=["ES256", "RS256"],
            audience="authenticated",
        )
        user_id = payload["sub"]
        exp = payload.get("exp")
        print(f"[KIRA backend] get_current_user: token valid — user_id={user_id}, exp={exp}")
    except pyjwt.ExpiredSignatureError:
        print("[KIRA backend] get_current_user: token EXPIRED")
        raise HTTPException(status_code=401, detail="Token has expired — please sign in again")
    except Exception as e:
        print(f"[KIRA backend] get_current_user: token decode failed — {e}")
        raise HTTPException(status_code=401, detail="Invalid authentication token")

    profile = get_user_profile(user_id)
    if not profile:
        print(f"[KIRA backend] get_current_user: no profile found for user_id={user_id}")
        raise HTTPException(status_code=403, detail="No officer profile found for this account")

    print(f"[KIRA backend] get_current_user: authorized — {profile['full_name']} ({profile['role']})")
    return {
        "user_id": user_id,
        "role": profile["role"],
        "full_name": profile["full_name"],
        "badge_number": profile.get("badge_number"),
    }


_POLICYMAKER_SUSPECT_BLOCK = (
    "Individual suspect records are restricted for your role. "
    "Aggregate cluster statistics are available — would you like a "
    "summary of Cluster K-7 activity instead?"
)


# --------------- app ---------------

app = FastAPI(title="KIRA Console — Conversational AI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/api/chat")
async def chat(req: ChatRequest, current_user: dict = Depends(get_current_user)):
    """
    Main conversational AI endpoint.
    Streams two SSE events:
      1. workspace_signal (~200ms) — Cerebras router result, triggers frontend animation
      2. narration (~1-2s)        — Gemini response text for the chat panel
    Requires a valid Supabase JWT. Enforces role-based content restrictions.
    """
    session_id = req.session_id or str(uuid.uuid4())
    user_id = current_user["user_id"]
    officer_role = current_user["role"]

    async def generate():
        session = await get_or_create_session(session_id, req.lang)
        current_workspace = session.get("current_workspace", "supervision")
        current_entity = session.get("current_entity")

        lang = req.lang
        if lang == "en":
            detected = await detect_language(req.query)
            if detected == "kn":
                lang = "kn"

        context_string = await get_recent_context_string(session_id)
        await save_message(session_id, "officer", req.query, user_id=user_id)

        routing = await classify_intent(
            query=req.query,
            current_workspace=current_workspace,
            current_entity=current_entity,
            recent_context=context_string,
        )

        target_workspace = routing.get("workspace", current_workspace)
        action = routing.get("action", "stay")
        entity = routing.get("entity") or current_entity
        confidence = routing.get("confidence", 0.9)
        detected_lang = routing.get("language", lang)
        if detected_lang == "kn":
            lang = "kn"

        agents_running = AGENT_SETS.get(target_workspace, [])

        # Policymaker restriction: block individual suspect queries
        if officer_role == "policymaker" and target_workspace == "suspect":
            signal_event = {
                "event": "workspace_signal",
                "workspace": "supervision",
                "action": "stay",
                "entity": None,
                "agents_running": [],
                "confidence": 1.0,
                "lang": lang,
            }
            yield f"data: {json.dumps(signal_event)}\n\n"
            yield f"data: {json.dumps({'event': 'narration', 'text': _POLICYMAKER_SUSPECT_BLOCK, 'lang': lang})}\n\n"
            await save_message(session_id, "ai", _POLICYMAKER_SUSPECT_BLOCK, user_id=user_id)
            yield f"data: {json.dumps({'event': 'done', 'session_id': session_id})}\n\n"
            return

        # Event 1: routing signal
        signal_event = {
            "event": "workspace_signal",
            "workspace": target_workspace,
            "action": action,
            "entity": entity,
            "agents_running": agents_running,
            "confidence": confidence,
            "lang": lang,
        }
        yield f"data: {json.dumps(signal_event)}\n\n"

        entity_data = get_entity_data(target_workspace, entity)
        history = await get_history(session_id, limit=8)

        narration = await generate_response(
            query=req.query,
            workspace=target_workspace,
            entity=entity,
            entity_data=entity_data,
            conversation_history=history,
            lang=lang,
        )

        # Event 2: AI narration text + optional map action
        narration_event: dict = {"event": "narration", "text": narration, "lang": lang}
        map_action = extract_map_action(req.query)
        if map_action:
            narration_event["map_action"] = map_action
        yield f"data: {json.dumps(narration_event)}\n\n"

        await update_session(session_id, target_workspace, entity)

        workspace_signal_record = {
            "workspace": target_workspace,
            "action": action,
            "entity": entity,
            "confidence": confidence,
        }
        await save_message(session_id, "ai", narration, user_id=user_id, workspace_signal=workspace_signal_record)

        yield f"data: {json.dumps({'event': 'done', 'session_id': session_id})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


@app.get("/api/session/{session_id}")
async def get_session(session_id: str):
    session = await get_or_create_session(session_id)
    history = await get_history(session_id, limit=20)
    return {"session": session, "history": history}


@app.get("/api/suspects/{name}")
async def get_suspect_detail(name: str):
    return {
        "suspect": get_suspect(name),
        "cases": get_suspect_cases(name),
        "evidence": get_suspect_evidence(name),
    }


@app.get("/api/hotspots")
async def get_hotspots_endpoint():
    return get_hotspots()


@app.get("/api/arrests")
async def get_arrests():
    return get_recent_arrests()


@app.get("/api/alerts")
async def get_alerts():
    """Rule-based proactive alert generation from live Supabase data."""
    from datetime import datetime
    hotspots = get_hotspots()
    arrests = get_recent_arrests(3)
    alerts = []
    now = datetime.now().strftime("%I:%M %p")

    for h in hotspots:
        if h.get("emerging") and h.get("risk_score", 0) >= 8.5:
            alerts.append({
                "severity": "critical", "border": "#F04E4E",
                "title": f"SURGE ALERT — {h['name']}",
                "body": f"{h['incidents']} incidents detected · {h['crime_type']} cluster flagged · Deploy patrol units",
                "time": now,
            })

    for h in hotspots:
        if not h.get("emerging") and h.get("risk_score", 0) >= 7.0:
            alerts.append({
                "severity": "high", "border": "#F5A623",
                "title": f"ESCALATION WATCH — {h['name']}",
                "body": f"{h['incidents']} weekly incidents · {h['crime_type']} · Risk score {h['risk_score']:.1f}/10",
                "time": now,
            })

    if arrests:
        a = arrests[0]
        alerts.append({
            "severity": "info", "border": "#4D9EF5",
            "title": f"ARREST INTELLIGENCE — {a.get('suspect_name', 'Unknown')}",
            "body": f"{a.get('charge', '')} · {a.get('location', '')} · Case {a.get('case_id', '')} updated",
            "time": a.get("arrest_date", now),
        })

    return {"alerts": alerts[:5], "generated_at": now}


@app.get("/api/audit")
async def get_audit_log(
    limit: int = 100,
    current_user: dict = Depends(get_current_user),
):
    """
    Audit trail. Supervisors see all officers' history; others see only their own.
    """
    entries = await get_audit_entries(
        limit=limit,
        requesting_user_id=current_user["user_id"],
        requesting_role=current_user["role"],
    )
    return {"entries": entries, "total": len(entries)}


@app.get("/api/financial/trail/{entity}")
async def money_trail(entity: str):
    """Directed graph traversal — downstream money trail up to 4 hops from a named entity."""
    from agents.financial_analysis import trace_money_trail
    return trace_money_trail(entity)


@app.get("/api/financial/layering/{case_id}")
async def layering_analysis(case_id: str):
    """Detect money-laundering layering indicators for a case (multi-hop, structuring, cash-out)."""
    from agents.financial_analysis import detect_layering_pattern
    return detect_layering_pattern(case_id)


@app.get("/api/suspects/{name}/risk")
async def suspect_risk_score(name: str):
    """Computed actuarial risk score with contributing factor breakdown."""
    from agents.risk_scoring import get_risk_score_for_suspect
    return get_risk_score_for_suspect(name)


@app.get("/api/cases/{case_id}/similar")
async def similar_cases_endpoint(case_id: str):
    """Semantic case similarity using sentence embeddings (all-MiniLM-L6-v2, cosine similarity)."""
    from agents.similar_cases import find_similar_cases
    return {"similar_cases": find_similar_cases(case_id)}


@app.get("/api/network/analysis")
async def network_analysis_endpoint():
    """
    Real graph-based network analysis using networkx + Louvain community detection.
    Builds the criminal network from live suspect/case/evidence/gang_members data.
    """
    from agents.network_analysis import detect_communities, get_centrality_scores
    communities = detect_communities()
    centrality = get_centrality_scores()
    return {"communities": communities, "centrality": centrality}


@app.get("/health")
async def health():
    return {"status": "ok", "service": "KIRA Conversational AI"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
