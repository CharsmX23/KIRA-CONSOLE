import os
import subprocess

port = (
    os.environ.get("X_ZOHO_CATALYST_LISTEN_PORT")
    or os.environ.get("PORT")
    or "8080"
)

print(f"[KIRA START] PORT={port}", flush=True)
subprocess.run([
    "python3", "-m", "uvicorn", "main:app",
    "--host", "0.0.0.0",
    "--port", port,
])
